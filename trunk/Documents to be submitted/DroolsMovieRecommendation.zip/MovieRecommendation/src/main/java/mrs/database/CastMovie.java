package mrs.database;

public class CastMovie {
	private int aid;
	private int mid;
	private String role;
	private String notes;
	private int creditNo;
	
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public int getCreditNo() {
		return creditNo;
	}
	public void setCreditNo(int creditNo) {
		this.creditNo = creditNo;
	}
	
	

}
