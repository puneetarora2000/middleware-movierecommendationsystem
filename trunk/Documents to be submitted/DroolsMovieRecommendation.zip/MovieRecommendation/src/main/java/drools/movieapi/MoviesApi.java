package drools.movieapi;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;


import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import mrs.database.CastMovie;
import mrs.database.MovieGenre;
import mrs.database.MovieLanguage;
import mrs.database.Movies;
import mrs.database.NowPlayingMovies;
import mrs.database.UpcomingMovies;

import drools.constants.Collections;
import drools.constants.Tables;
import drools.email.SendMail;
import drools.moviedb.MongoDB;
import drools.moviedb.MySQLDB;

public class MoviesApi {
	private MySQLDB MovieDB;
	private MongoDB mongoDB;
	
	public MoviesApi() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, MalformedURLException, UnknownHostException {
		System.out.println("Connecting to DB");
		mongoDB = new MongoDB();
		System.out.println("Connected to DB");
		MovieDB = new MySQLDB();		
	}
	
	// to be tested by JUnit
	public boolean nowPlayingMovies() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, IOException, org.json.simple.parser.ParseException, ParseException {
		StringTokenizer dateToken;
		//DB failure
		if(MovieDB == null || mongoDB == null)
			return false;
		try {
		MovieDB.connectDB();
		MovieDB.truncateTable(Tables.NOW_PLAYING_MOVIES.getName());
		}
		catch(Exception e) {
			return false; //DB failure
		}
		
		System.out.println("Fetching now Playing list");
		URL new_movie_url=new URL("http://api.themoviedb.org/3/movie/now_playing?api_key=e88aa0025e49b8c50140cc3db7710376");
		File new_movie_json=new File("NowPlayingMovies.json");
		FileUtils.copyURLToFile(new_movie_url,new_movie_json);	
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(new FileReader("NowPlayingMovies.json"));
		JSONObject jsonObject = (JSONObject) obj;
		JSONArray movies = (JSONArray) jsonObject.get("results");
		System.out.println("Fetched now playing movies list");
		//failure in fetching data from public API
		if(movies.size() == 0 )
			return false;
		for(int j=0; j < movies.size(); j++) { 
			JSONObject element =  (JSONObject) movies.get(j);
			NowPlayingMovies nowPlayingMovie = new NowPlayingMovies();
			try {
			nowPlayingMovie.setTitle(element.get("title").toString());
			nowPlayingMovie.setMid(Integer.parseInt(element.get("id").toString())*10);
			dateToken = new StringTokenizer(element.get("release_date").toString(),"-");
			nowPlayingMovie.setYear(Integer.parseInt(dateToken.nextToken()));
			System.out.print("Title: " + element.get("title").toString());
			System.out.println("Year: " + Integer.parseInt(dateToken.nextToken()));
			System.out.println("Mid: " + Integer.parseInt(element.get("id").toString())*10);
			}
			catch (Exception e) {
				continue;
			}
			MovieDB.insertNowPlayingMovie(nowPlayingMovie);
        }
		MovieDB.commitDB();
		MovieDB.closeDB();
		return true;
	}

	// to be tested by JUnit
	public boolean upcomingMovies() throws IOException, org.json.simple.parser.ParseException, SQLException, ParseException, InstantiationException, IllegalAccessException, ClassNotFoundException  {
		StringTokenizer dateToken;
		Movies movie;
		//DB failure
		if(MovieDB == null || mongoDB == null)
			return false;
		try {
		MovieDB.connectDB();
		MovieDB.truncateTable(Tables.UPCOMING_MOVIES.getName());
		}
		catch(Exception e) {
			return false; //DB failure
		}
		System.out.println("Fetching upcoming movies list");
		URL new_movie_url=new URL("http://api.themoviedb.org/3/movie/upcoming?api_key=e88aa0025e49b8c50140cc3db7710376");
		File new_movie_json=new File("UpcomingMovies.json");
		FileUtils.copyURLToFile(new_movie_url,new_movie_json);	
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(new FileReader("UpcomingMovies.json"));
		JSONObject jsonObject = (JSONObject) obj;
		JSONArray movies = (JSONArray) jsonObject.get("results");
		System.out.println("Fetched upcoming movies list");
		//failure in fetching data from public API
		if(movies.size() == 0 )
			return false;
		for(int j=0; j < movies.size(); j++) { // Iterate each element in the elements array
			try {
			JSONObject element =  (JSONObject) movies.get(j);
			UpcomingMovies upcomingMovie = new UpcomingMovies();
			upcomingMovie.setTitle(element.get("title").toString());
			upcomingMovie.setMid(Integer.parseInt(element.get("id").toString())*10);
			dateToken = new StringTokenizer(element.get("release_date").toString(),"-");
			upcomingMovie.setYear(Integer.parseInt(dateToken.nextToken()));
			System.out.print("Title: " + element.get("title").toString());
			System.out.println("Year: " + Integer.parseInt(dateToken.nextToken()));
			System.out.println("Mid: " + Integer.parseInt(element.get("id").toString())*10);
			MovieDB.insertUpcomingMovie(upcomingMovie);
			movie = new Movies();
			movie.setMid(upcomingMovie.getMid());
			movie.setTitle(upcomingMovie.getTitle());
			movie.setYear(upcomingMovie.getYear());
			System.out.println("Updating Master Movies list");
			updateMoviesList(movie);
			} 
			catch(Exception e) {
				continue;
			}
        }
		MovieDB.commitDB();
		MovieDB.closeDB();
		return true;
	}
	
	public void updateMoviesList(Movies movie) {
		if(MovieDB.checkMovie(movie.getMid())==0) {
			System.out.println("Adding "+movie.getMid()+" to Master Movies list");
			MovieDB.insertMovie(movie);
			updateCastMovie(movie);
			updateMovieGenre(movie);
			updateMovieLanguage(movie);
		}
	}
	
	private void updateMovieLanguage(Movies movie) {
		MovieLanguage movieLanguage = new MovieLanguage();
		movieLanguage.setMid(movie.getMid());
		movieLanguage.setLid(1);
		MovieDB.insertMovie(movieLanguage);
	}

	private void updateMovieGenre(Movies movie) {
		MovieGenre movieGenre = new MovieGenre();
		movieGenre.setMid(movie.getMid());
		movieGenre.setGid(11);
		MovieDB.insertMovie(movieGenre);
	}

	private void updateCastMovie(Movies movie) {
		CastMovie castMovie = new CastMovie();
		castMovie.setAid(100);
		castMovie.setMid(movie.getMid());
		castMovie.setRole("Hero");
		MovieDB.insertMovie(castMovie);
	}
	
	private String getTagValue(String sTag, Element eElement) {
		NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
	    Node nValue = (Node) nlList.item(0);
		return nValue.getNodeValue();
	  }
	
	public void searchMovies() {
		// to do
	}
	
	public void commitChanges() {
		MovieDB.commitDB();
		MovieDB.closeDB();
	}
	
	// to be tested by JUnit
	public boolean generateRecommendation() throws IOException, org.json.simple.parser.ParseException, InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		int mid, similarMid;
		System.out.println("Generating Recommendation for users");
		//DB failure
		if(MovieDB == null || mongoDB == null)
			return false;
		try {
		mongoDB.connectUserDB();
		mongoDB.getUserList();
		MovieDB.connectDB();
		}
		catch(Exception e) {
			return false; //DB failure 
		}
		System.out.println("List of all users");
		while(mongoDB.cursor.hasNext()) {
			JSONObject updateUser = new JSONObject();
			DBObject user = mongoDB.cursor.next();
			if(user.get("history").toString().contains("[ ]")) {
				System.out.println("No history so no recommendation!!");
				continue;
			}
			//System.out.println("history field: " + user.get("history"));
			if(user.get("userId") != null)
				updateUser.put("userId", user.get("userId").toString());
			else
				updateUser.put("userId", null);	
			if(user.get("email") != null)
				updateUser.put("email", user.get("email").toString());
			else
				updateUser.put("email", null);	
			if(user.get("passwd") != null)
				updateUser.put("passwd", user.get("passwd").toString());
			else
				updateUser.put("passwd", null);
			if(user.get("gender") != null)
				updateUser.put("gender", user.get("gender").toString());
			else
				updateUser.put("gender", null);
			if(user.get("firstName") != null)
				updateUser.put("firstName", user.get("firstName").toString());
			else
				updateUser.put("firstName", null);
			if(user.get("lastName") != null)
				updateUser.put("lastName", user.get("lastName").toString());
			else
				updateUser.put("lastName", null);
			if(user.get("age") != null)
				updateUser.put("age", user.get("age").toString());
			else
				updateUser.put("age", null);
			if(user.get("lang") != null)
				updateUser.put("lang", user.get("lang").toString());
			else
				updateUser.put("lang", null);
			if(user.get("loc") != null)
				updateUser.put("loc", user.get("loc").toString());
			else
				updateUser.put("loc", null);
			if(user.get("history") != null)
				updateUser.put("history", user.get("history"));
			else
				updateUser.put("history", null);
			
			BasicDBList history = (BasicDBList)user.get("history");
			JSONArray favMovies = new JSONArray();
			//System.out.println("List: "+history);
			if(history != null)
			{
			for(Iterator it = history.iterator(); it.hasNext();) {
				DBObject historyElement;
				try {
					historyElement = (DBObject) it.next();
				}
				catch(Exception e) {
					System.out.println("Not valid entries in history");
					continue;
				}
				JSONObject fav = new JSONObject();
				mid = Math.round(Float.parseFloat(historyElement.get("id").toString()));
				URL similarMovieUrl=new URL("http://api.themoviedb.org/3/movie/"+(mid/10)+"/similar_movies?api_key=e88aa0025e49b8c50140cc3db7710376");
				File similarMovieJson=new File("similarMovie.json");
				try {
				FileUtils.copyURLToFile(similarMovieUrl,similarMovieJson);
				}
				catch (Exception e) {
					System.out.println("Skipping bad Movie ID");
					continue;
				}
				JSONParser parser = new JSONParser();
				Object obj = parser.parse(new FileReader("similarMovie.json"));
				JSONObject jsonObject = (JSONObject) obj;
				JSONArray movies = (JSONArray) jsonObject.get("results");
				if(movies.size()>0) {
					String similarMovieName;
					JSONObject element =  (JSONObject) movies.get(1);
					similarMovieName = element.get("title").toString();
					System.out.println("Similar Movie: --------"+similarMovieName);
					/*BasicDBObject movieUpdate = new BasicDBObject().append("$push", 
							new BasicDBObject().append("favTitle", similarMovieName));
					mongoDB.collection.update(user, movieUpdate);*/
					
					fav.put("title", similarMovieName);
					if(!favMovies.contains(fav))
					{
						System.out.println("Original:" + similarMovieName);
						favMovies.add(fav);
					}
					else
						System.out.println("Duplicate entry: " + similarMovieName);
					similarMid = Integer.parseInt(element.get("id").toString())*10;
					/*fav.put("id", similarMid);
					favMovies.add(fav);*/
					Movies movie = getMovieInfo(similarMid/10);
					updateMoviesList(movie);
				}
		    }
			}
			updateUser.put("favMovies", favMovies);
			System.out.println(updateUser);
			/*for(int j=0; j < history.size(); j++) { // Iterate each element in the elements array
				JSONObject element =  (JSONObject) history.get(j);
				System.out.println("ID: "+ Integer.parseInt(element.get("id").toString()));
	        }*/
			mongoDB.removeUser(user);
			mongoDB.addUser(updateUser);
		}
		try {
		mongoDB.closeDB();
		MovieDB.commitDB();
		MovieDB.closeDB();
		}
		catch(Exception e) {
			return false; // DB failure
		}
		return true;
	}
	
	// to be tested by JUnit
	public boolean emailRecommendation() throws IOException, org.json.simple.parser.ParseException, InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		System.out.println("Emailing Recommendation for users");
		try {
		mongoDB.connectUserDB();
		mongoDB.getUserList();
		MovieDB.connectDB();
		}
		catch(Exception e) {
			return false; // DB failure
		}
		System.out.println("List of all users");	
		while(mongoDB.cursor.hasNext()) {
			int mid;
			List<String> favEmailList = new ArrayList<String>();
			DBObject user = mongoDB.cursor.next();
			BasicDBList favMoviesList = (BasicDBList)user.get("favMovies");
			for(Iterator it = favMoviesList.iterator(); it.hasNext();) {
				DBObject favElement = (DBObject) it.next();
				mid = Math.round(Float.parseFloat(favElement.get("id").toString()));
				Movies movie = getMovieInfo(mid/10);
				favEmailList.add(movie.getTitle());
		    }
			System.out.println("Username: "+ favEmailList.toString());
			SendMail sendMail = new SendMail("ggvishnu29@gmail.com", user.get("email").toString(), "Recommended Movies", favEmailList.toString());
			sendMail.send();
			System.out.println("Email sent");
		}
		try {
		mongoDB.closeDB();
		MovieDB.commitDB();
		MovieDB.closeDB();
		}
		catch(Exception e) {
			return false; // DB failure
		}
		return true;
	}
	
	public Movies getMovieInfo(int mid) throws IOException, org.json.simple.parser.ParseException {
		Movies movie = new Movies();
		URL movieInfoUrl=new URL("http://api.themoviedb.org/3/movie/"+mid+"?api_key=e88aa0025e49b8c50140cc3db7710376");
		File movieInfoJson=new File("MovieInfo.json");
		FileUtils.copyURLToFile(movieInfoUrl,movieInfoJson);	
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(new FileReader("MovieInfo.json"));
		JSONObject element = (JSONObject) obj;
		movie.setMid(mid*10);
		movie.setTitle(element.get("title").toString());
		StringTokenizer dateToken = new StringTokenizer(element.get("release_date").toString(),"-");
		movie.setYear(Integer.parseInt(dateToken.nextToken()));
		return movie;
	}
	
	public boolean updateMovieRating(int mid, double rating) throws UnknownHostException {
		System.out.println("Updating rating for movies");
		try {
			mongoDB.connectMovieDB();
			mongoDB.updateMovieRating(mid, rating);
			mongoDB.closeDB();
			return true;
		}
		catch(Exception e) {
			return false;
		}
	}
	
	public boolean updateMovieReview(int mid, String review) throws UnknownHostException {
		try {
			System.out.println("Adding review for movies");		
			mongoDB.connectMovieDB();
			mongoDB.updateMovieReview(mid, review);
			mongoDB.closeDB();
			return true;
		}
		catch(Exception e) {
			return false;
		}
	}
	
	
	public void MovieAsPerson(int mid, String username) throws IOException, org.json.simple.parser.ParseException, InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		System.out.println("Movie with person lastname matching");
		mongoDB.connectUserDB();
		mongoDB.getUserList();
		MovieDB.connectDB();
		System.out.println("List of all users - MovieAsPerson");	
		while(mongoDB.cursor.hasNext()) {
			int midTemp;
			DBObject user = mongoDB.cursor.next();
			BasicDBList favMoviesList = (BasicDBList)user.get("favMovies");
			for(Iterator it = favMoviesList.iterator(); it.hasNext();) {
				DBObject favElement = (DBObject) it.next();
				midTemp = Math.round(Float.parseFloat(favElement.get("id").toString()));
				Movies movie = getMovieInfo(midTemp/10);
			}
	}
	}
	
	//to be tested by JUnit
	public boolean insertSingleRecommendation(String collection, String key, String userName) throws UnknownHostException, InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		String movieName = null;
		try {
			mongoDB.connectMovieDB();
			mongoDB.getFavList(collection);
		}
		catch(Exception e) {
			return false;
		}
		while(mongoDB.cursor.hasNext()) {
			System.out.println("One record");
			DBObject favRecord = mongoDB.cursor.next();
			System.out.println("Age Record: " + favRecord.toString());
			//System.out.println("Key: " + key);
			if(favRecord.get(key) != null)
				movieName = favRecord.get(key).toString();
			else
				movieName = null;
		}
		try {
			mongoDB.closeDB();
		}
		catch (Exception e) {
			return false;
		}
		System.out.println("movieName" + movieName);
		System.out.println("UserName" + userName);
		this.insertRecommendation(movieName, userName);
		return true;
	}
	
	
	// to be tested by JUnit
	public boolean insertRecommendation(String movieName, String userName) throws UnknownHostException, InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		if(movieName == null)
			return true;  // no movie is added
		System.out.println("Generating Recommendation for users");
		int statusCheck = 0;
		try {
		mongoDB.connectUserDB();
		mongoDB.getUserList();
		}
		catch(Exception e) {
			return false; // DB failure
		}
		System.out.println("List of all users");
		while(mongoDB.cursor.hasNext()) {
			JSONObject updateUser = new JSONObject();
			DBObject user = mongoDB.cursor.next();
			if(user.get("userId").toString().equals(userName)) {
				System.out.println("Found the user: "+ user.get("userId").toString()); 
				try {
				DBObject query = new BasicDBObject("favMovies.title", movieName);
				query.put("userId", userName);
				DBCursor result = mongoDB.collection.find(query);
				//System.out.println("Fav test:" + getFav.toString());
				if(result.size() > 0)
				{
					System.out.println("Already existing movie!!!");
					return true;
					
				}
				}
				catch(Exception e) {
					return false; // DB failure
				}
				System.out.println("user size: "+user.get("userId").toString());
				if(user.get("userId") != null)
					updateUser.put("userId", user.get("userId").toString());
				else
					updateUser.put("userId", null);	
				if(user.get("email") != null)
					updateUser.put("email", user.get("email").toString());
				else
					updateUser.put("email", null);	
				if(user.get("passwd") != null)
					updateUser.put("passwd", user.get("passwd").toString());
				else
					updateUser.put("passwd", null);
				if(user.get("history") != null)
					updateUser.put("history", user.get("history").toString());
				else
					updateUser.put("history", null);
				if(user.get("gender") != null)
					updateUser.put("gender", user.get("gender").toString());
				else
					updateUser.put("gender", null);
				if(user.get("firstName") != null)
					updateUser.put("firstName", user.get("firstName").toString());
				else
					updateUser.put("firstName", null);
				if(user.get("lastName") != null)
					updateUser.put("lastName", user.get("lastName").toString());
				else
					updateUser.put("lastName", null);
				if(user.get("age") != null)
					updateUser.put("age", user.get("age").toString());
				else
					updateUser.put("age", null);
				if(user.get("lang") != null)
					updateUser.put("lang", user.get("lang").toString());
				else
					updateUser.put("lang", null);
				if(user.get("loc") != null)
					updateUser.put("loc", user.get("loc").toString());
				else
					updateUser.put("loc", null);
				if(user.get("duration") != null)
					updateUser.put("duration", user.get("duration").toString());
				else
					updateUser.put("duration", null);
				if(user.get("timeperiod") != null)
					updateUser.put("timeperiod", user.get("timeperiod").toString());
				else
					updateUser.put("timeperiod", null);
				if(user.get("mood") != null)
					updateUser.put("mood", user.get("mood").toString());
				else
					updateUser.put("mood", null);
				BasicDBList favList = (BasicDBList)user.get("favMovies");
				JSONArray favMovies = new JSONArray();
				if(favList != null ) {
				for(Iterator it = favList.iterator(); it.hasNext();) {
					DBObject favElement;
					JSONObject fav = new JSONObject();
					try {
						favElement = (DBObject) it.next();
					}
					catch(Exception e) {
						System.out.println("Not valid entries in FavList");
						continue;
					}
					String similarMovieName;
					similarMovieName = favElement.get("title").toString();
					fav.put("title", similarMovieName);
					favMovies.add(fav);
				}
				}
				JSONObject favNew = new JSONObject();
				favNew.put("title",movieName);
				favMovies.add(favNew);
				updateUser.put("favMovies", favMovies);
				System.out.println(updateUser);
				mongoDB.removeUser(user);
				mongoDB.addUser(updateUser);
				statusCheck = 1;
				break;
			}	
		}
		if(statusCheck == 0)
			return false;
		try {
		mongoDB.closeDB();		
		}
		catch(Exception e) {
			return false; // DB failure
		}
		return true;
	}
}
