package drools.main;

import drools.movieapi.MoviesApi;

public class TestMain {
	public static void main(String[] args) throws Exception {
		DroolsApi test = new DroolsApi();
		test.createKnowledgeBase();
		test.insertRecommendation("bala");
		test.fireRules();
		System.out.println("Rules fired!");
	}
}
